<?php
echo "Connection successful!";
?>
